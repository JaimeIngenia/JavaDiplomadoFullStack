
package RutaN;


public class Main {
    public static void main(String [] args){
    valorAbsoluto Jaime = new valorAbsoluto();
    Jaime.pedir();
    Jaime.valor();
    }
}
