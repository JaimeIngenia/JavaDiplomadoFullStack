
package RutaN;


public class Main {
    public static void main(String [] args){
        promedio jaime = new promedio();
        jaime.calcula(2,2, 2, 2, 2);
    }
}
