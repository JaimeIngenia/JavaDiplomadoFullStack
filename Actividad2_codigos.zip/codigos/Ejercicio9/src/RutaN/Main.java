
package RutaN;

public class Main {
    public static void main (String [] args){
        salario jaime = new salario();
        jaime.pedir_salario(10);
    }
}
