
package RutaN;


public class Main {
    
    
    public static void main(String [] args){
        
        
    NombreSexoPeso NombreSexoPesoJaime = new NombreSexoPeso();
    NombreSexoPeso Dilbani = new NombreSexoPeso();
    
    
    NombreSexoPesoJaime.PedirNombre();
    NombreSexoPesoJaime.MostrarHermano();
    
    }

}