
package RutaN;

public class Main {
    public static void main(String [] args){
        ecuacion jaime = new ecuacion();
        jaime.y(5);
    }
}
