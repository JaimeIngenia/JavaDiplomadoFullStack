
package RutaN;


public class ecuacion {
    //ATRIBUTOS
    int resultado = 0;
    //METODOS
    public void y(int x){
       resultado = 3*(2*x)+(7*x)-1;
       System.out.println(resultado);
    }
    
}
