package CalculaNumeroMayor;


public class Main {
    public static void main(String [] args){
        
        claseNumeroMayor claseNumeroMayorJaime = new claseNumeroMayor();
        
        claseNumeroMayorJaime.leerNumeros();
        claseNumeroMayorJaime.menor();
        claseNumeroMayorJaime.mayor();
        claseNumeroMayorJaime.raiz();
        claseNumeroMayorJaime.potencia();
        claseNumeroMayorJaime.mostrar();
        
    }
}
