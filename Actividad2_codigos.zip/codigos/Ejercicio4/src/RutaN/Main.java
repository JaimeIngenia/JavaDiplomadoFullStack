
package RutaN;


public class Main {
    public static void main(String [] args){
        ecuacionCuadratica jaime = new ecuacionCuadratica();
        jaime.funcion(1, 2, 3);
    }
}
