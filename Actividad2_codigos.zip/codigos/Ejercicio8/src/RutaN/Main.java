
package RutaN;

public class Main {
    public static void main (String [] args){
        areaCirculo jaime = new areaCirculo();
        jaime.area();
    
    }
    
}
