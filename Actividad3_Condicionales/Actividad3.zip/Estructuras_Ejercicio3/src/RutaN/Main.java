package RutaN;

public class Main {
    public static void main(String [] args){
        mayorNivel jaime = new mayorNivel();
        jaime.solicitar();
        jaime.condicional();
        jaime.producto();
        jaime.dividir();
    }
    
}
