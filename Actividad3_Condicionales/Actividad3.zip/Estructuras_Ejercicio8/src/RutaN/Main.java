
package RutaN;

import java.io.IOException;


public class Main {
    public static void main(String [] args)throws IOException{
        validar jaime = new validar();
        jaime.pedirDatos();
        jaime.calcula();
    }
}
