package RutaN;


public class Main {
    public static void main(String [] args){
        alumno jaime = new alumno();
        jaime.pedir();
        jaime.promedioCondicion();
    }
}
