
package RutaN;


public class Main {
    public static void main(String [] args){
        Promedio jaime = new Promedio();
        jaime.condicion();
    }
}
