
package RutaN;


public class Main {
    public static void main(String [] args){
        mayor jaimr = new mayor();
        jaimr.mayor();
    }
}
