
package RutaN;


public class Main {
    public static void main(String [] args){
        impuestos jaime = new impuestos();
        jaime.calcular();
    }
}
