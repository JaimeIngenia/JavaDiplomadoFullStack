
package RutaN;

import java.io.IOException;

public class Main {
    public static void main(String [] args)throws IOException{
        numerosCantidad jaime = new numerosCantidad();
        jaime.tresNumerosPedir();
        jaime.calcula();
    }
}
