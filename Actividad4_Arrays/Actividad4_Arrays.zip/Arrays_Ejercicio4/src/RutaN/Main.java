
package RutaN;


public class Main {
    public static void main(String [] args){
        media jaime = new media();
        jaime.registro();

    }
}
