
package RutaN;


public class Main {
    public static void main(String [] args){
        habitantes jaime = new habitantes();
        
        jaime.a();
    }
}
