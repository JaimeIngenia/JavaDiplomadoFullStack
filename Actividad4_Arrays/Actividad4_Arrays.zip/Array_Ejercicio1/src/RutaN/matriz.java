
package RutaN;

public class matriz {
    //Atributos
    int n1;
    //Metodos
    public void a(){
    n1 = 5;
    System.out.println(n1+"Este es un mensaje");
    }

}
