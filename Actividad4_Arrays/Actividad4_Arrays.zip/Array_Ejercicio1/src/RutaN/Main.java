
package RutaN;


public class Main {
    public static void main(String [] args){
        matriz jaime = new matriz();
        System.out.println("Este es un mensaje");
        jaime.a();
    }
    
}
