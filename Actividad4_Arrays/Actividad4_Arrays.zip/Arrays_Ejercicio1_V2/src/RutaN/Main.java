
package RutaN;


public class Main {
    public static void main(String [] args){
        matriz jaime = new matriz();
        jaime.pedir();
        jaime.llenar();
        jaime.imprimirMatriz();
        jaime.MayorColumna();
        jaime.descendente();
        jaime.menorFila();
        
    }
    
}
